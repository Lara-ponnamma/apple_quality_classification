from tkinter import*
import tkinter as tk
from PIL import Image,ImageTk
from tkinter import PhotoImage

window = tk.Tk()
window.geometry("1000x1000")
window.title("APPLE QUALITY PREDICTION")

image = Image.open("a.jpg")
i1= ImageTk.PhotoImage(image)
label = Label(image=i1).place(x = 0,y = 0)

l1 = tk.Label(text = "SIZE",bg = 'white',fg = 'black')
l1.place(x = 50,y  =50)
l2 = tk.Label(text = "WEIGHT",bg = 'white',fg = 'black')
l2.place(x = 50,y  =100)
l3 = tk.Label(text = "SWEETNESS",bg = 'white',fg = 'black')
l3.place(x = 50,y  =150)
l4 = tk.Label(text = "CHRUNCHINESS",bg = 'white',fg = 'black')
l4.place(x = 50,y  =200)
l5 = tk.Label(text = "JUCINESS",bg = 'white',fg = 'black')
l5.place(x = 50,y  = 250)
l6 = tk.Label(text = "RIPNESS",bg = 'white',fg = 'black')
l6.place(x = 50,y  =300)
l7 = tk.Label(text = "ACIDITY",bg = 'white',fg = 'black')
l7.place(x = 50,y  = 350)
l8 = tk.Label(text = "QUALITY",bg = 'white',fg = 'black')
l8.place(x = 50,y  = 400)

text1 = tk.Entry()
text1.place(x = 500,y = 50)
text2 = tk.Entry()
text2.place(x = 500,y = 100)
text3 = tk.Entry()
text3.place(x = 500,y = 150)
text4 = tk.Entry()
text4.place(x = 500,y = 200)
text5 = tk.Entry()
text5.place(x = 500,y = 250)
text6 = tk.Entry()
text6.place(x = 500,y = 300)
text7 = tk.Entry()
text7.place(x = 500,y = 350)
text8 = tk.Entry()
text8.place(x = 500,y = 400)
text9 = tk.Entry(width = 40)
text9.place(x = 200,y = 500)


import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns

import warnings
warnings.filterwarnings('ignore')

from sklearn.preprocessing import LabelEncoder
from sklearn.preprocessing import StandardScaler

from sklearn.model_selection import train_test_split
from sklearn.linear_model import LogisticRegression
from sklearn.tree import DecisionTreeClassifier
from sklearn.ensemble import RandomForestClassifier

from sklearn.metrics import confusion_matrix, accuracy_score, classification_report

df = pd.read_csv("D:\\apple_quality\\apple_quality.csv")

df.dropna(inplace = True)

df.drop('A_id',axis = 1,inplace = True)

df['Quality'] = df['Quality'].replace({'bad':0,'good':1})

x = df.drop('Quality',axis = 1)
y = df['Quality']
x_train,x_test,y_train,y_test = train_test_split(x,y,test_size = 0.3,random_state = 1)

rt = RandomForestClassifier()
rt.fit(x_train,y_train)
y_pred = rt.predict(x_test)

def predict():
    new = np.array([float(text1.get()),float(text2.get()),float(text3.get()),float(text4.get()),float(text5.get()),float(text6.get()),float(text7.get())])
    ans = rt.predict([new])[0]
    text8.insert(0,ans)

    if ans == 1:
        text9.insert(0,"APPLE QUALITY IS REALLY GOOD")
    else:
        text9.insert(0,"APPLE QUALITY IS REALLY BAD")

con = confusion_matrix(y_test,y_pred)
print(con)

cla = classification_report(y_test,y_pred)
print(cla)

acc = accuracy_score(y_test,y_pred)
print("accuracy score", acc)


def clear():
    text1.delete(0,END)
    text2.delete(0,END)
    text3.delete(0,END)
    text4.delete(0,END)
    text5.delete(0,END)
    text6.delete(0,END)
    text7.delete(0,END)
    text8.delete(0,END)
    text9.delete(0,END)

button1 = tk.Button(text = "PREDICT",bg = 'white',fg = 'black',command = predict).place(x = 50,y = 450)
button2 = tk.Button(text = "CLEAR",bg = 'white',fg = 'black',command = clear).place(x = 500,y = 450)
window.mainloop()